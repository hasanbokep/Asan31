pkg update && pkg upgrade
pkg install bash
pkg install git
git clone https://github.com/Rajkumrdusad/onex
cd onex
chmod +x onex
chmod +x install
./install
sh install


Cara menggunakannya lgsg saja

onex start
